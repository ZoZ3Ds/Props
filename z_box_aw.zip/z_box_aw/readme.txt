Thank you for your purchase.
You can use this package for your own purposes, on a Fivem server, but it is forbidden to resell it.
Thank you for reading.

All of the modells has embedded texture.

Prop name : z_box_aw
         

YTYP name:  z_box_aw

Installation for the props: 
	      1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

