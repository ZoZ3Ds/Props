fx_version 'cerulean'
game { 'gta5' }
author 'ZoZ3D'
description 'CottonCandy Props'
version '1.1.0'





-- loading props --
data_file 'DLC_ITYP_REQUEST' 'stream/z_ccandy.ytyp' 





