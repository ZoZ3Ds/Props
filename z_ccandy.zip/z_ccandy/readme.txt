Thank you for your purchase.
You can use this package for your own purposes, on a Fivem server, but it is forbidden to resell it.
Thank you for reading.

All of the modells has embedded texture.

Prop name : z_ccandy_b
            z_ccandy_p
YTYP name : z_ccandy
Installation for the props: 
	      1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

